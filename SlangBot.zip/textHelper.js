'use strict';
var textHelper = (function () {
    return {
        completeHelp: 'Here\'s some things you can say,'
        + ' define friends,'
        + ' what is a baller,'
        + ' tell me what is CNN,'
        + ' what\'s ebay,'
        + ' and cancel.',

        nextHelp: ' You can ask another word or phrase'
    };
})();
module.exports = textHelper;
